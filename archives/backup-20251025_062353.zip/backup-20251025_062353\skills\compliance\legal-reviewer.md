# Legal Reviewer

Review legal compliance and contracts.

Capabilities: License compliance, contract review, privacy policy
