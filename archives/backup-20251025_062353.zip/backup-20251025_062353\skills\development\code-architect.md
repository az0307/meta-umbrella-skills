# Code Architect

Design software architecture and create technical specifications.

Capabilities: System design, tech stack selection, API specs, database schema
