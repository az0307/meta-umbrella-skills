# Brand Designer

Create brand identity and visual assets.

Capabilities: Logo design, brand guidelines, color palettes, typography
