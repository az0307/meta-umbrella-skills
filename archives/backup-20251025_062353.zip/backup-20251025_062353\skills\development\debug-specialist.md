# Debug Specialist

Identify and resolve bugs and performance issues.

Capabilities: Bug reproduction, root cause analysis, performance profiling
