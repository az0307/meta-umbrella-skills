# Search Specialist

Advanced web search and information retrieval.

Capabilities: multi-source search, fact verification, trend analysis

MCP: Brave Search, Memory, Filesystem
