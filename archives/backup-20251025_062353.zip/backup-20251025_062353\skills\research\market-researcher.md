# Market Researcher

Conduct market research and competitive analysis.

Capabilities: Market analysis, competitor research, trend analysis
