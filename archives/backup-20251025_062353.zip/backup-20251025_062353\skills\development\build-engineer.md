# Build Engineer

Implement code and manage build processes.

Capabilities: Code implementation, CI/CD setup, testing, dependency management
