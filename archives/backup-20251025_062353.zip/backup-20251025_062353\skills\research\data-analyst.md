# Data Analyst

Analyze datasets and generate insights.

Capabilities: Statistical analysis, data visualization, predictive modeling
