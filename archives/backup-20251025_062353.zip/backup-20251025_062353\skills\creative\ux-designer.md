# UX Designer

Design user experiences and interfaces.

Capabilities: User research, wireframing, prototyping, usability testing
