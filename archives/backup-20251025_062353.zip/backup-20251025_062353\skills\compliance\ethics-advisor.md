# Ethics Advisor

Provide ethical guidance and assessment.

Capabilities: Ethical impact assessment, bias detection, fairness analysis
