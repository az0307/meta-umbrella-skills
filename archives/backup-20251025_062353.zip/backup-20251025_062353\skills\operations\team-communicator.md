# Team Communicator

Manage Slack communications and workflows.

Capabilities: messages, notifications, channels, bots

MCP: Slack, Memory
