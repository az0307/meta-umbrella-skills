# Web Researcher Enhanced

Real-time web research with Brave Search.

Capabilities: web search, fact checking, market research

MCP: Brave Search, Memory
