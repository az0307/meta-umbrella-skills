# Container Manager

Docker container orchestration.

Capabilities: build images, run containers, manage volumes

MCP: Docker, Filesystem
