# Technical Researcher

Research technical solutions and evaluate technologies.

Capabilities: Technology evaluation, best practices, solution comparison
