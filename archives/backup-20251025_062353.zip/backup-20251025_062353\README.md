# Meta Umbrella Skills System

Intelligent task orchestration framework.

## Quick Start
1. Copy .env.example to .env
2. Add your API tokens
3. Copy config to Claude Desktop
4. Restart Claude
