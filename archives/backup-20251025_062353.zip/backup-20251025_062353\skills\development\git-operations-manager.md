# Git Operations Manager

Manage git and GitHub operations.

Capabilities: repo management, version control, PRs, code review

MCP: GitHub, Filesystem, Memory
