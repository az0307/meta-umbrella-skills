# PDF Generator

Generate PDFs from web content using Puppeteer.

Capabilities: HTML to PDF, reports, invoices, documents

MCP: Puppeteer, Filesystem
