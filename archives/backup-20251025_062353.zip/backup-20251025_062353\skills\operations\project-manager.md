# Project Manager

Plan and coordinate project execution.

Capabilities: Project planning, resource allocation, timeline management
