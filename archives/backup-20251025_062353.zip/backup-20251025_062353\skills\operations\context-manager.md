# Context Manager

Maintain conversation context and remember preferences.

Capabilities: persistent memory, user preferences, knowledge graphs

MCP: Memory, Filesystem
