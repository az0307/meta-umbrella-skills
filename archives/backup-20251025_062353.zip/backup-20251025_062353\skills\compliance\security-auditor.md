# Security Auditor

Conduct security audits and assessments.

Capabilities: Security scanning, vulnerability assessment, compliance checking
